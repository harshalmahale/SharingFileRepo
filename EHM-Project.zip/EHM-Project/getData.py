import pyodbc
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from pydantic import BaseModel

# from typing import List
import numpy as np

import re
from transformers import pipeline
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk


app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

conn = pyodbc.connect(
    "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",
    autocommit=True,
)
cursor = conn.cursor()

df = pd.read_sql_query("SELECT * FROM Emotional_health_data", conn)


# to all get data of all employees
@app.get("/employees")
async def get_employees():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    cursor = conn.cursor()
    cursor.execute(
        """SELECT * FROM Emotional_health_data ORDER BY CASE WHEN Feedback = 'stressed' THEN 0 ELSE 1 END, Emp_Code;"""
    )
    columns = [column[0] for column in cursor.description]
    data = []
    for row in cursor.fetchall():
        data.append(dict(zip(columns, row)))
    cursor.close()
    conn.close()
    return {"data": data}


# to get count of stressed people bu wise
@app.get("/bustresscount")
async def get_count():
    df = pd.read_sql_query("select * from Emotional_health_data", conn)
    count = df.groupby(["BU"])["Feedback"].value_counts()
    stressed_counts = count.loc[(slice(None), "Stressed")]
    data = stressed_counts.to_dict()
    return data


# to get count of stressed people location wise
@app.get("/loacationstresscount")
async def get_count():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    # cursor = conn.cursor()
    df = pd.read_sql_query("select * from Emotional_health_data", conn)
    count = df.groupby(["Emp_Location"])["Feedback"].value_counts()
    stressed_counts = count.loc[(slice(None), "Stressed")]
    data = stressed_counts.to_dict()
    return data


# all data(bu,du,location,review) loaction wise
@app.get("/stressed_by_location")
def get_stressed_by_location():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    # cursor = conn.cursor()
    df = pd.read_sql_query("select * from Emotional_health_data", conn)
    stressed = df[df["Feedback"] == "Stressed"]
    stressed_by_location = stressed.groupby("Emp_Location")[
        ["Emp_Name", "Emp_Code", "BU", "DU"]
    ]
    result = []
    for location, group in stressed_by_location:
        location_data = {
            "location": location,
            "employees": group[["Emp_Name", "Emp_Code", "BU", "DU"]].to_dict(
                orient="records"
            ),
        }
        result.append(location_data)
    return result


# all data(bu,du,location,review) bu wise
@app.get("/stressed_by_bu")
def get_stressed_by_location():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    # cursor = conn.cursor()
    df = pd.read_sql_query("select * from Emotional_health_data", conn)
    stressed = df[df["Feedback"] == "Stressed"]
    stressed_by_location = stressed.groupby("BU")[
        ["BU", "DU", "Emp_Location", "Review"]
    ]
    result = []
    for location, group in stressed_by_location:
        location_data = {
            "location": location,
            "employees": group[["BU", "DU", "Emp_Location", "Review"]].to_dict(
                orient="records"
            ),
        }
        result.append(location_data)
    return result


# all count of stressed and not stressed people
@app.get("/all_count")
def get_all_count():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    # cursor = conn.cursor()
    df = pd.read_sql_query("select * from Emotional_health_data", conn)
    feedback_count = df["Feedback"].value_counts()
    data = feedback_count.to_dict()
    return data


# download necessary resources
nltk.download("stopwords")
nltk.download("wordnet")
nltk.download("omw-1.4")

# define stopwords and lemmatizer
stop = stopwords.words("english")
not_stopwords = ["not"]
final_stop_words = set([word for word in stop if word not in not_stopwords])
new_stopwords = ["na", "cons", "none"]
final_stop_words = final_stop_words.union(new_stopwords)
le = WordNetLemmatizer()

# # define pipelin
sentiment_pipeline = pipeline("sentiment-analysis")

# function to preprocess review text
def preprocess_review(review):
    x = re.sub("[^a-zA-Z]", " ", str(review))
    x = x.split()
    x = [le.lemmatize(word) for word in x if word not in set(final_stop_words)]
    return " ".join(x)


# function to get sentiment prediction for a review
@app.get("/predict_sentiment")
def predict_sentiment(review: str):
    preprocessed_review = preprocess_review(review)
    prediction = sentiment_pipeline(preprocessed_review)[0]
    print(prediction)
    sentiment = prediction["label"]
    score = prediction["score"]
    return {"sentiment": sentiment, "score": score}


class EmotionalData(BaseModel):
    id: int
    bu: str
    du: str
    emp_name: str
    emp_location: str
    review: str
    feedback: str
    question_1: str
    question_2: str
    question_3: str
    date: str


# insert data from Form into database
@app.post("/insert-data")
async def insert_data(data: EmotionalData):
    try:
        # insert data into database with sentiment and score
        conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",            autocommit=True,
        )
        cursor = conn.cursor()
        query = f"INSERT INTO Emotional_health_data VALUES ({data.id}, '{data.bu}', '{data.du}', '{data.emp_name}', '{data.emp_location}', '{data.review}', '{data.feedback}','{data.question_1}','{data.question_2}','{data.question_3}','{data.date}')"
        cursor.execute(query)
        conn.commit()
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail={"error": str(e)})


@app.get("/count_of_radioAns_bu")
async def get_radioCount():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )  # Read the data
    # Read the data from the database
    df = pd.read_sql_query("select * from Emotional_health_data", conn)

    # Group the data by BU and get the chng_sleep_ptrn, difficulty_focusing, and feeling_stuck columns
    grouped_data = (
        df.groupby("BU")[["chng_sleep_ptrn", "difficulty_focusing", "feeling_stuck"]]
        .apply(lambda x: x.to_dict("records"))
        .to_dict()
    )

    # Iterate over each BU in the grouped_data and get the count of 'Yes' and 'No' for each column
    for bu, data in grouped_data.items():
        bu_data = pd.DataFrame(data)
        bu_counts = bu_data.apply(pd.Series.value_counts).fillna(0).astype(int)
        bu_counts = bu_counts.transpose()

    return bu_counts


@app.get("/count_of_radioAns_loc")
async def get_radioCount():
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    df = pd.read_sql_query("select * from Emotional_health_data", conn)
    count_of_radioAns = df.groupby("Emp_Location")[
        ["chng_sleep_ptrn", "difficulty_focusing", "feeling_stuck"]
    ].count()
    data = count_of_radioAns.to_dict()
    return data


# Define an endpoint for getting the emotional health data
@app.get("/qans_bu")
async def get_emotional_health_data():
    # Read the data from the database
    df = pd.read_sql_query("select * from Emotional_health_data", conn)

    # Group the data by BU and get the chng_sleep_ptrn, difficulty_focusing, and feeling_stuck columns
    grouped_data = (
        df.groupby("BU")[["chng_sleep_ptrn", "difficulty_focusing", "feeling_stuck"]]
        .apply(lambda x: x.to_dict("records"))
        .to_dict()
    )

    # Iterate over each BU in the grouped_data and get the count of 'Yes' and 'No' for each column
    result = {}
    for bu, data in grouped_data.items():
        bu_data = pd.DataFrame(data)
        bu_counts = bu_data.apply(pd.Series.value_counts).fillna(0).astype(int)
        bu_counts = bu_counts.transpose()
        result[bu] = bu_counts.to_dict()

    return result


# Define an endpoint for getting the emotional health data
@app.get("/qans_loc")
async def get_emotional_health_data():
    # Read the data from the database
    df = pd.read_sql_query("select * from Emotional_health_data", conn)

    # Group the data by BU and get the chng_sleep_ptrn, difficulty_focusing, and feeling_stuck columns
    grouped_data = (
        df.groupby("Emp_Location")[
            ["chng_sleep_ptrn", "difficulty_focusing", "feeling_stuck"]
        ]
        .apply(lambda x: x.to_dict("records"))
        .to_dict()
    )
    # Iterate over each BU in the grouped_data and get the count of 'Yes' and 'No' for each column
    result = {}
    for loc, data in grouped_data.items():
        loc_data = pd.DataFrame(data)
        loc_counts = loc_data.apply(pd.Series.value_counts).fillna(0).astype(int)
        loc_counts = loc_counts.transpose()
        result[loc] = loc_counts.to_dict()

    return result


@app.get("/du_wise_count")
async def get_du_count():
    du_count = df.groupby(["BU", "DU"])["Feedback"].value_counts()
    data = du_count.loc[:, :, "Stressed"]
    data_d = data.to_dict()

    # to get BU as outer key and DU as inner key
    data_dict = {}
    for key, value in data_d.items():
        bu = key[0]
        du = key[1]
        count = value
        if bu not in data_dict:
            data_dict[bu] = {}
        data_dict[bu][du] = count

    return data_dict


@app.get("/compare_count_bu")
async def read_emotional_health_data(sd: str, ed: str):
    conn = pyodbc.connect(
       "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",        autocommit=True,
    )
    cursor = conn.cursor()

    query = "SELECT * FROM Emotional_health_data WHERE Survey_date BETWEEN ? AND ?"
    cursor.execute(query, (sd, ed))
    result_set = cursor.fetchall()

    columns = [column[0] for column in cursor.description]
    result = []
    for row in result_set:
        result.append(dict(zip(columns, row)))
    data = pd.DataFrame(result)
    s_count = data[data["Feedback"] == "Stressed"].groupby("BU")["Feedback"].count()

    return s_count.to_dict()
