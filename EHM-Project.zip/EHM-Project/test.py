import pyodbc,pandas as pd
conn = pyodbc.connect(
    "DRIVER={ODBC Driver 17 for SQL Server};SERVER=PSL-71527L3;DATABASE=Emotional_health_monitoring;Trusted_Connection=yes;",
    autocommit=True,
)
cursor = conn.cursor()

df = pd.read_sql_query("SELECT * FROM Emotional_health_data", conn)
print(df.head())