import React from "react";
import LocationList from "./components/LocationList";
import { Routes, Route } from "react-router-dom";
import ListScreen from "./components/ListScreen";
import HomeScreen from "./components/HomeScreen";
import SurveyForm from "./components/Form";
// import SForm from "./components/Sform";
import Home from "./components/Home";

const App = () => {
  return (
    <div>
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/" element={<HomeScreen />} />
        <Route path="form" element={<SurveyForm />} />
        <Route path="/location" element={<LocationList />} />
        <Route path="/bu" element={<ListScreen />} />
      </Routes>
    </div>
  );
};

export default App;
