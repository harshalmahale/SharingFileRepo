import React from "react";
import lamp from "../images/lamp.png";
import light from "../images/light.png";
// import logo from "../images/logo1.png";
import menu from "../images/menu.png";
import "./Home.css";

const Home = () => {
  return (
    <div>
      <div className="hero">
        <nav>
          <img className="menu-img" src={menu} alt=""></img>
          <h3 className="logo">EHM</h3>
          <a className="dashboard-button" href="/" alt="">
            Dashboard
          </a>
        </nav>

        <div className="lamp-container">
          <img className="lamp" src={lamp} alt=""></img>
          <img className="light" src={light} id="light" alt=""></img>
        </div>

        <div className="text-container">
          <h1 className="headline">Strong, healthy functioning families </h1>

          <p className="para">
            This is the basic Sentimental survey taken from you, So that
            institution can also understand you better.{" "}
          </p>
          <a href="/form" alt="">
            Take Survey
          </a>

          <a
            href="https://www.mentalhealth.gov/basics/what-is-mental-health"
            alt=""
          >
            Depression ? What's it ?
          </a>
        </div>
      </div>
    </div>
  );
};

export default Home;
