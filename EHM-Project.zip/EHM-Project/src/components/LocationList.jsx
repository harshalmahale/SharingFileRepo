import React, { useState, useEffect } from "react";
import Graphs from "./Graphs";
import "../App.css";

// import axios from "axios";

const LocationList = () => {
  //   const [data, setData] = useState({});
  const [stressData, setStressData] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/stressed_by_location")
      .then((response) => response.json())
      .then((data) => setStressData(data));
  }, []);

  //   conso;
  return (
    <>
      <Graphs
        url="http://localhost:8000/loacationstresscount"
        heading="Location wise Stress"
      />
      <div className="table">
        <table className="diaplayTable">
          <thead>
            <tr>
              <th>Employee Name</th>
              <th>Employee Code</th>
              <th>BU</th>
              <th>DU</th>
            </tr>
          </thead>
          <tbody>
            {stressData.map((location) => (
              <React.Fragment key={location.location}>
                <tr>
                  <th style={{ marginLeft: "10rem" }} colSpan="4">
                    {location.location}
                  </th>
                </tr>
                {location.employees.map((emp) => (
                  <tr key={emp.Emp_Code}>
                    <td>{emp.Emp_Name}</td>
                    <td>{emp.Emp_Code}</td>
                    <td>{emp.BU}</td>
                    <td>{emp.DU}</td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default LocationList;
