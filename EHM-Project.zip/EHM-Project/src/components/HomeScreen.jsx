import React, { useEffect, useState } from "react";
import axios from "axios";
import "./HomeScreen.css";
import "../App.css";
import Graphs from "./Graphs";

const HomeScreen = () => {
  const [employeeData, setEmployeeData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await axios.get("http://localhost:8000/employees");
      const data = response.data.data;
      setEmployeeData(data);
    };
    fetchData();
  }, []);

  return (
    <>
      <div className="top-buttons">
        <a className="btn-next" href="/bu">
          See data BU wise
        </a>

        <a className="btn-next" href="/location" alt="  ">
          See data Location wise
        </a>
      </div>
      <Graphs url="http://localhost:8000/all_count" />
      <div className="table">
        <table>
          <thead>
            <tr>
              <th>Emp Code</th>
              <th>BU</th>
              <th>DU</th>
              <th>Emp Name</th>
              <th>Emp Location</th>
              <th>Review</th>
              <th>Feedback</th>
            </tr>
          </thead>
          <tbody>
            {employeeData.map((employee) => (
              <tr key={employee.Emp_Code}>
                <td>{employee.Emp_Code}</td>
                <td>{employee.BU}</td>
                <td>{employee.DU}</td>
                <td>{employee.Emp_Name}</td>
                <td>{employee.Emp_Location}</td>
                <td>{employee.Review}</td>
                <td>{employee.Feedback}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default HomeScreen;
