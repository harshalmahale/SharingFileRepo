import React, { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  // CartesianGrid,
  Tooltip,
  // Legend,
} from "recharts";
import "./Graphs.css";

const StressedCount = (props) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch(props.url)
      .then((response) => response.json())
      .then((data) => {
        const formattedData = Object.keys(data).map((key) => ({
          feedback: key,
          count: data[key],
        }));
        setData(formattedData);
      });
  }, [props.url]);

  return (
    <div>
      <h2> {props.heading} </h2>
      <div className="barGraph">
        <BarChart width={600} height={400} data={data}>
          {/* <CartesianGrid strokeDasharray="3 3" /> */}
          <XAxis dataKey="feedback" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="count" fill="orangered" />
        </BarChart>
      </div>
    </div>
  );
};

export default StressedCount;
