import React, { useState } from "react";
// import "./Web.css";
import "./Form.css";

const SurveyForm = () => {
  // const ReviewForm = () => {
  const [id, setId] = useState("");
  const [bu, setBu] = useState("");
  const [du, setDu] = useState("");
  const [emp_name, setEmp_name] = useState("");
  const [emp_location, setEmp_location] = useState("");
  const [review, setReview] = useState("");
  // const [feedback, setFeedback] = useState("");
  // const [response, setResponse] = useState("");

  const handleBu = (event) => {
    setBu(event.target.value);
  };
  const handleDu = (event) => {
    setDu(event.target.value);
  };

  const handleLocation = (event) => {
    setEmp_location(event.target.value);
  };

  // const handleInputChange = (event) => {
  //   const { name, value } = event.target;
  //   setFormData({ ...formData, [name]: value });
  // };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Call the predict_sentiment API
    fetch(`http://localhost:8000/predict_sentiment?review=${review}`)
      .then((response) => response.json())
      .then((result) => {
        const sentiment =
          result.sentiment === "POSITIVE" ? "Not Stressed" : "Stressed";

        // Call the insert_data API with the sentiment result as a parameter
        const data = {
          id: id,
          col1: bu,
          col2: du,
          col3: emp_name,
          city: emp_location,
          schedule: review,
          da: sentiment,
        };

        fetch("http://localhost:8000/insert-data", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        })
          .then((response) => response.json())
          .then((result) => {
            // setResponse(`Status: ${result.status}`);
            // window.location.reload(true);
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      })
      .catch((error) => {
        console.error("Error:", error);
      });
    alert("Submitted Successfully");
    window.location.href = "/home";
  };
  // };

  return (
    <div class="formbold-form-wrapper">
      <h1>Survey Form</h1>
      <img class="back-gr" src="" alt="" />
      <form onSubmit={(event) => handleSubmit(event)}>
        <div class="formbold-input-group">
          <label for="id" class="formbold-form-label">
            Employee Code :
          </label>
          <input
            type="number"
            id="id"
            name="id"
            class="formbold-form-input"
            value={id}
            onChange={(e) => setId(e.target.value)}
            required
          />
          <br></br>
        </div>

        <div className="formbold-input-group">
          <label htmlFor="bu" className="formbold-form-label">
            BU:
          </label>
          <div>
            <select
              className="formbold-form-input"
              value={bu}
              onChange={handleBu}
              required
            >
              <option value="">Select BU</option>
              <option value="BFSI">BFSI</option>
              <option value="PES">PES</option>
              <option value="HLS">HLS</option>
              <option value="Cloud Practice">Cloud Practice</option>
            </select>
          </div>
        </div>

        {/* <div class="formbold-input-group">
          <label for="bu" class="formbold-form-label">
            BU:
          </label>
          <input
            type="text"
            id="bu"
            name="bu"
            class="formbold-form-input"
            value={bu}
            onChange={(e) => setBu(e.target.value)}
          />
          <br></br>
        </div> */}

        {/* <div class="formbold-input-group">
          <label for="du" class="formbold-form-label">
            DU:
          </label>
          <input
            type="text"
            id="du"
            name="du"
            class="formbold-form-input"
            value={du}
            onChange={(e) => setDu(e.target.value)}
          />
          <br></br>
        </div> */}
        <div className="formbold-input-group">
          <label htmlFor="bu" className="formbold-form-label">
            DU:
          </label>
          <div>
            <select
              className="formbold-form-input"
              value={du}
              onChange={handleDu}
              required
            >
              <option value="">Select DU</option>
              <option value="DU1">DU1</option>
              <option value="DU2">DU2</option>
              <option value="DU3">DU3</option>
              <option value="DU4">DU4</option>
              <option value="DU5">DU5</option>
              <option value="DU6">DU6</option>
              <option value="DU7">DU7</option>
              <option value="DU8">DU8</option>
              <option value="DU9">DU9</option>
            </select>
          </div>
        </div>

        <div class="formbold-input-group">
          <label for="emp_name" class="formbold-form-label">
            Employee Name:
          </label>
          <input
            type="text"
            id="emp_name"
            name="emp_name"
            class="formbold-form-input"
            value={emp_name}
            onChange={(e) => setEmp_name(e.target.value)}
            required
          />
          <br></br>
        </div>

        <div className="formbold-input-group">
          <label htmlFor="bu" className="formbold-form-label">
            Employee Location:
          </label>
          <div>
            <select
              className="formbold-form-input"
              value={emp_location}
              onChange={handleLocation}
              required
            >
              <option value="">Select Location</option>
              <option value="pune">Pune</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Nagpur">Nagpur</option>
            </select>
          </div>
        </div>

        <div className="harshChaSparsh">
          <p>
            <strong>Note:</strong>
          </p>
          <p> 1 : Bad </p>
          <p> 2 : Neutral </p>
          <p> 3 : Good </p>
        </div>

        <div>
          <label for="que1" class="formbold-form-label">
            1. How was your day?
          </label>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que1"
              id="rad1"
              value="1"
            />
            <label class="form-check-label" for="rad1">
              1
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que1"
              id="rad1"
              value="2"
            />
            <label class="form-check-label" for="rad1">
              2
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que1"
              id="rad1"
              value="3"
            />
            <label class="form-check-label" for="rad1">
              3
            </label>
          </div>

          <br></br>
        </div>

        <div>
          <label for="que2" class="formbold-form-label">
            2. My job enables me to learn and develop new skills.
          </label>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que2"
              id="rad2"
              value="1"
            />
            <label class="form-check-label" for="rad2">
              1
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que2"
              id="rad2"
              value="2"
            />
            <label class="form-check-label" for="rad1">
              2
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que2"
              id="rad2"
              value="3"
            />
            <label class="form-check-label" for="rad1">
              3
            </label>
          </div>

          <br></br>
        </div>

        <div>
          <label for="que3" class="formbold-form-label">
            3. My physical work environment contributes positively to my ability
            to do my job
          </label>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que3"
              id="rad3"
              value="1"
            />
            <label class="form-check-label" for="rad1">
              1
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que3"
              id="rad3"
              value="2"
            />
            <label class="form-check-label" for="rad1">
              2
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que3"
              id="rad3"
              value="3"
            />
            <label class="form-check-label" for="rad1">
              3
            </label>
          </div>

          <br></br>
        </div>

        <div>
          <label for="que4" class="formbold-form-label">
            4. The demands of my workload are manageable.
          </label>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que4"
              id="rad4"
              value="1"
            />
            <label class="form-check-label" for="rad1">
              1
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que4"
              id="rad4"
              value="2"
            />
            <label class="form-check-label" for="rad1">
              2
            </label>
          </div>

          <div class="form-check form-check-inline">
            <input
              class="form-check-input"
              type="radio"
              name="que4"
              id="rad4"
              value="3"
            />
            <label class="form-check-label" for="rad1">
              3
            </label>
          </div>

          <br></br>
        </div>

        <div>
          <label for="review" class="formbold-form-label">
            How was your Week?
          </label>
          <br></br>
          <textarea
            rows="6"
            name="review"
            id="review"
            placeholder="Type here..."
            class="formbold-form-input"
            value={review}
            onChange={(e) => setReview(e.target.value)}
            required
          ></textarea>
        </div>
        <br></br>
        <input type="submit" className="form-btn" />
      </form>
    </div>
  );
};

export default SurveyForm;
