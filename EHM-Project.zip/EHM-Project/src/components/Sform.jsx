import React, { useState } from "react";

export default function SForm() {
  const [id, setId] = useState("");
  const [col1, setCol1] = useState("");
  const [col2, setCol2] = useState("");
  const [col3, setCol3] = useState("");
  const [city, setCity] = useState("");
  const [schedule, setSchedule] = useState("");
  const [review, setReview] = useState("");
  const [response, setResponse] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    // Call the predict_sentiment API
    fetch(`http://localhost:8000/predict_sentiment?review=${review}`)
      .then((response) => response.json())
      .then((result) => {
        const sentiment =
          result.sentiment === "POSITIVE" ? "Not Stressed" : "Stressed";

        // Call the insert_data API with the sentiment result as a parameter
        const data = {
          id: id,
          col1: col1,
          col2: col2,
          col3: col3,
          city: city,
          schedule: schedule,
          da: sentiment,
        };

        fetch("http://localhost:8000/insert-data", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        })
          .then((response) => response.json())
          .then((result) => {
            setResponse(`Status: ${result.status}`);
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>
          ID:
          <input
            type="text"
            value={id}
            onChange={(event) => setId(event.target.value)}
          />
        </label>
        <br />
        <label>
          Col 1:
          <input
            type="text"
            value={col1}
            onChange={(event) => setCol1(event.target.value)}
          />
        </label>
        <br />
        <label>
          Col 2:
          <input
            type="text"
            value={col2}
            onChange={(event) => setCol2(event.target.value)}
          />
        </label>
        <br />
        <label>
          Col 3:
          <input
            type="text"
            value={col3}
            onChange={(event) => setCol3(event.target.value)}
          />
        </label>
        <br />
        <label>
          City:
          <input
            type="text"
            value={city}
            onChange={(event) => setCity(event.target.value)}
          />
        </label>
        <br />
        <label>
          Schedule:
          <input
            type="text"
            value={schedule}
            onChange={(event) => setSchedule(event.target.value)}
          />
        </label>
        <br />
        <label>
          Review:
          <input
            type="text"
            value={review}
            onChange={(event) => setReview(event.target.value)}
          />
        </label>
        <br />

        <br />
        <button type="submit">Submit</button>
        <p>{response}</p>
      </form>
      {/* <button onClick={handleSubmit()}>Submit</button> */}
    </div>
  );
}

// export default ReviewForm;
